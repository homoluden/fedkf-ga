-----------------------
 FileHelpers for MONO
-----------------------

This version of the FileHelpers for MONO have all the 
features of the standard version.

You must take it as EXPERIMENTAL in this release we have
too little feedback about the use in big real apps.

Please dont hesitate in contact us with feedback about
any problem we will get soon to you to fix any problem:

     mono@filehelpers.com

Happy Coding
Marcos